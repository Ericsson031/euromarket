<pre>Array
(
    [currentFolderPath] => ../../img/cms/
    [new_folder] => Images_CMS
)
</pre>

03/Oct/2013 12:12:52