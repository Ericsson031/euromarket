<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{watermark}prestashop>watermark_ee20bb60493f049175fc10c35acd2272'] = 'Filigran';
$_MODULE['<{watermark}prestashop>watermark_0c11c1cf80c1aa9144a03b97f0bbf0ba'] = 'Bir PNG Filigran ile resminizi koruyun';
$_MODULE['<{watermark}prestashop>watermark_fa214007826415a21a8456e3e09f999d'] = 'Ayrıntıları silmek istediğinizden eminmisiniz.';
$_MODULE['<{watermark}prestashop>watermark_e7bbd7019d9f73bc63f406de1422d989'] = 'Bu modül düzgün çalışması için filigran görüntüsü sırayla yüklenmesi gerekir.';
$_MODULE['<{watermark}prestashop>watermark_f26d820220f1db94ea35bb61d95a80f4'] = 'Gerekli şeffaflık.';
$_MODULE['<{watermark}prestashop>watermark_78d0b1c450a31c9728488a6b0a893e8a'] = 'Şeffaflık uygun aralıkta değil.';
$_MODULE['<{watermark}prestashop>watermark_d31c2d99614d8e16430d2d8c99c1f2b0'] = 'Y-Ayarı gereklidir.';
$_MODULE['<{watermark}prestashop>watermark_8fe9c39f4bf87082caabcf3650970c71'] = 'Y-İstenilen ebatta değil.';
$_MODULE['<{watermark}prestashop>watermark_c2cf8e33c907a4cc689881dc8fa571c2'] = 'X-Ayarı gereklidir.';
$_MODULE['<{watermark}prestashop>watermark_3a1f788dbe8957be92048606cf0d3fcb'] = 'X-İstenilen ebatta değil.';
$_MODULE['<{watermark}prestashop>watermark_a9cac4be0fa0b815376b96f49e1435d7'] = 'En az bir resim türü gereklidir.';
$_MODULE['<{watermark}prestashop>watermark_31f79a5c1eccda9f507e82a284b1a4d8'] = 'Resim PNG formatında olmalıdır.';
$_MODULE['<{watermark}prestashop>watermark_130aab6764f25267c79cef371270eb2a'] = 'Bir hata oluştu yükleme filigran:%% 1 $ s 2 $ s';
$_MODULE['<{watermark}prestashop>watermark_444bcb3a3fcf8389296c49467f27e1d6'] = 'tamam';
$_MODULE['<{watermark}prestashop>watermark_c888438d14855d7d96a2724ee9c306bd'] = 'Ayarlarının güncellenmesi';
$_MODULE['<{watermark}prestashop>watermark_c0275788cf97660b52ab23f1f8c7c8d7'] = 'Filigran ayrıntılarını';
$_MODULE['<{watermark}prestashop>watermark_cc99ba657a4a5ecf9d2d7cb974d25596'] = 'Modül yüklendikten sonra, Tercihlerden \" resimler \" seçeneğini kullanarak resim tırnakları yeniden oluşturlmalıdır. Bundan sonra resimler otomatik olarak filigranlı olacak.';
$_MODULE['<{watermark}prestashop>watermark_c23549e174914e9796db47d27c49eb95'] = 'Filigran yüklenemedi.';
$_MODULE['<{watermark}prestashop>watermark_c9519bff5a6fe31e0f26b1c52dad7ad8'] = 'Filigran dosyası';
$_MODULE['<{watermark}prestashop>watermark_bc593fec128401a0317fcc850a67a115'] = 'PNG formatında olmalı';
$_MODULE['<{watermark}prestashop>watermark_3ccc25c1409aec574beb82bad14b5ebc'] = 'Filigran şeffaflığı (0-100)';
$_MODULE['<{watermark}prestashop>watermark_acf0fa79a73731e7d70cb208a62c249a'] = 'Filigran X boyutu';
$_MODULE['<{watermark}prestashop>watermark_489f2e730102b59aec48b5c27d2cbe1c'] = 'Filigran Y boyutu';
$_MODULE['<{watermark}prestashop>watermark_8d92a725c5abead5353e60e0b2fc7d6d'] = 'Filigran korunması için görüntü türlerini seçin.';
$_MODULE['<{watermark}prestashop>watermark_b17f3f4dcf653a5776792498a9b44d6a'] = 'Ayarları güncelle';
$_MODULE['<{watermark}prestashop>watermark_ab58d1563ccf9c7a98953f578d5822d8'] = 'Filigran dosyası PNG formatında değil. Lütfen formatı değiştiriniz.';

$_MODULE['<{watermark}prestashop>watermark_872e6b7b596ba4f395669f1fc7ce9974'] = 'Bu prestashop modülü tarafından değiştirilmiş ve geliştirilmiştir';
$_MODULE['<{watermark}prestashop>watermark_25c5b70b569b15316bfcf561f68fbeec'] = '* Bu modül yararlı ve sizin için mümkün olup olmadığını bir bağış yaptı, ben çok takdir ediyorum, beni geliştirmeye devam yardım!';
$_MODULE['<{watermark}prestashop>watermark_caf45c4c99de0621b7f954625234b480'] = '* Ben diğer modüller prestashop keşfetmeye davet ediyoruz';
$_MODULE['<{watermark}prestashop>watermark_6181061bda29c9835ee598681f42972d'] = 'Bu sayfayı ziyaret.';
$_MODULE['<{watermark}prestashop>watermark_cbb4d3dccd7508314fc733d97faee7f5'] = 'Akım değeri:';
$_MODULE['<{watermark}prestashop>watermark_bc593fec128401a0317fcc850a67a115'] ='PNG olmalıdır.';
$_MODULE['<{watermark}prestashop>watermark_34fc7767a43be8e05ecf735ba89b93f3'] ='Orijinal görüntü karşı filigran oranı';

