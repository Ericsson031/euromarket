<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{watermark}prestashop>watermark_ee20bb60493f049175fc10c35acd2272'] = 'Marca de agua (filigrana)';
$_MODULE['<{watermark}prestashop>watermark_8d7c07bcea7e80d072308e4bd4cc37b0'] = 'Proteja la imagen por una marca de agua en formato PNG';
$_MODULE['<{watermark}prestashop>watermark_fa214007826415a21a8456e3e09f999d'] = '¿Está seguro de querer suprimir los detalles?';
$_MODULE['<{watermark}prestashop>watermark_e7bbd7019d9f73bc63f406de1422d989'] = 'La imagen de la Marca de agua (filigrana) tiene que ser cargada para que este módulo funcione correctamente';
$_MODULE['<{watermark}prestashop>watermark_f26d820220f1db94ea35bb61d95a80f4'] = 'La transparencia es obligatoria';
$_MODULE['<{watermark}prestashop>watermark_78d0b1c450a31c9728488a6b0a893e8a'] = 'La transparencia no esta en la gama permitida';
$_MODULE['<{watermark}prestashop>watermark_d31c2d99614d8e16430d2d8c99c1f2b0'] = 'Se necesita alineación Y';
$_MODULE['<{watermark}prestashop>watermark_8fe9c39f4bf87082caabcf3650970c71'] = 'Alineación Y no permitida.';
$_MODULE['<{watermark}prestashop>watermark_c2cf8e33c907a4cc689881dc8fa571c2'] = 'Se necesita alineación X';
$_MODULE['<{watermark}prestashop>watermark_3a1f788dbe8957be92048606cf0d3fcb'] = 'Alineación X no permitida.';
$_MODULE['<{watermark}prestashop>watermark_a9cac4be0fa0b815376b96f49e1435d7'] = 'Se requiere al menos un tipo de imagen.';
$_MODULE['<{watermark}prestashop>watermark_b670770ad59c1f8e7fb65f276074172b'] = 'La imagen debe ser en formato  GIF';
$_MODULE['<{watermark}prestashop>watermark_130aab6764f25267c79cef371270eb2a'] = 'Ocurrió un error al cargar marca de agua: %1$s en %2$s';
$_MODULE['<{watermark}prestashop>watermark_444bcb3a3fcf8389296c49467f27e1d6'] = 'ok';
$_MODULE['<{watermark}prestashop>watermark_c888438d14855d7d96a2724ee9c306bd'] = 'Ajustes actualizados';
$_MODULE['<{watermark}prestashop>watermark_c0275788cf97660b52ab23f1f8c7c8d7'] = 'Detalles de la filigrana';
$_MODULE['<{watermark}prestashop>watermark_cc99ba657a4a5ecf9d2d7cb974d25596'] = 'Una vez que haya creado el módulo, tiene que regenerar las imágenes a utilizar en la herramienta Preferencias> Imágenes. Sin embargo, la filigrana se añadirá automáticamente en las nuevas imágenes.';
$_MODULE['<{watermark}prestashop>watermark_c23549e174914e9796db47d27c49eb95'] = 'La marca de agua no se ha subido';
$_MODULE['<{watermark}prestashop>watermark_c9519bff5a6fe31e0f26b1c52dad7ad8'] = 'Archivo de la filigrana';
$_MODULE['<{watermark}prestashop>watermark_ce4ca541df51a63fd8e78e0da29e1d44'] = 'Debe ser en formato GIF';
$_MODULE['<{watermark}prestashop>watermark_3ccc25c1409aec574beb82bad14b5ebc'] = 'Transparencia de la marca de agua (0-100)';
$_MODULE['<{watermark}prestashop>watermark_acf0fa79a73731e7d70cb208a62c249a'] = 'Alineación X de la marca de agua';
$_MODULE['<{watermark}prestashop>watermark_489f2e730102b59aec48b5c27d2cbe1c'] = 'Alineación Y de la marca de agua';
$_MODULE['<{watermark}prestashop>watermark_8d92a725c5abead5353e60e0b2fc7d6d'] = 'Elija el tipo de imagen para proteger la filigrana (necesita ser PNG)';
$_MODULE['<{watermark}prestashop>watermark_b17f3f4dcf653a5776792498a9b44d6a'] = 'Ajustes actualizados';
$_MODULE['<{watermark}prestashop>watermark_220d9102465c9223781b8f99af48c154'] = 'Su imagen filigrana no es un verdadero formato gif, conviértalo en lugar de renombrarlo';

$_MODULE['<{watermark}prestashop>watermark_872e6b7b596ba4f395669f1fc7ce9974'] = 'Este módulo de prestashop ha sido modificado y mejorado por';
$_MODULE['<{watermark}prestashop>watermark_25c5b70b569b15316bfcf561f68fbeec'] = '* Si este módulo te ha sido de utilidad y te es posible, te agradecería enormente si hicieras una donacion, ¡ me ayudará a continuar mejorando!';
$_MODULE['<{watermark}prestashop>watermark_caf45c4c99de0621b7f954625234b480'] = '* Le invito a descubrir otros módulos de prestashop';
$_MODULE['<{watermark}prestashop>watermark_6181061bda29c9835ee598681f42972d'] = 'visitando esta página.';
$_MODULE['<{watermark}prestashop>watermark_cbb4d3dccd7508314fc733d97faee7f5'] = 'Valor actual:';
$_MODULE['<{watermark}prestashop>watermark_bc593fec128401a0317fcc850a67a115'] ='Debe tener formato PNG';
$_MODULE['<{watermark}prestashop>watermark_34fc7767a43be8e05ecf735ba89b93f3'] ='Proporción de marca de agua frente imagen original';

