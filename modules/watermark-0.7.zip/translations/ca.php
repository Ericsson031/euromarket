<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{watermark}prestashop>watermark_ee20bb60493f049175fc10c35acd2272'] = 'Filigrana (marca d\'aigua)';
$_MODULE['<{watermark}prestashop>watermark_8d7c07bcea7e80d072308e4bd4cc37b0'] = 'Protegir la imatge amb una filigrana';
$_MODULE['<{watermark}prestashop>watermark_fa214007826415a21a8456e3e09f999d'] = 'Està segur que vol esborrar les seves dades?';
$_MODULE['<{watermark}prestashop>watermark_e7bbd7019d9f73bc63f406de1422d989'] = 'Imatge de marca d\'aigua s\'ha de carregar perquè aquest mòdul funcioni correctament.';
$_MODULE['<{watermark}prestashop>watermark_f26d820220f1db94ea35bb61d95a80f4'] = 'Transparència necessària.';
$_MODULE['<{watermark}prestashop>watermark_78d0b1c450a31c9728488a6b0a893e8a'] = 'La transparència no éstà en el rang permès';
$_MODULE['<{watermark}prestashop>watermark_d31c2d99614d8e16430d2d8c99c1f2b0'] = 'L\'alineació Y és necessària.';
$_MODULE['<{watermark}prestashop>watermark_8fe9c39f4bf87082caabcf3650970c71'] = 'L\'alineació Y no éstà en el rang permès';
$_MODULE['<{watermark}prestashop>watermark_c2cf8e33c907a4cc689881dc8fa571c2'] = 'L\'alineació X és necessària.';
$_MODULE['<{watermark}prestashop>watermark_3a1f788dbe8957be92048606cf0d3fcb'] = 'L\'alineació X no éstà en el rang permès';
$_MODULE['<{watermark}prestashop>watermark_a9cac4be0fa0b815376b96f49e1435d7'] = 'Almenys un tipus d\'imatge és necessari.';
$_MODULE['<{watermark}prestashop>watermark_b670770ad59c1f8e7fb65f276074172b'] = 'La imatge ha d\'estar en format GIF.';
$_MODULE['<{watermark}prestashop>watermark_130aab6764f25267c79cef371270eb2a'] = 'Ha succeït un error mentre es pujava la marca d\'aigua: %1$s a %2$s';
$_MODULE['<{watermark}prestashop>watermark_444bcb3a3fcf8389296c49467f27e1d6'] = 'd\'acord';
$_MODULE['<{watermark}prestashop>watermark_c888438d14855d7d96a2724ee9c306bd'] = 'Configuració modificada';
$_MODULE['<{watermark}prestashop>watermark_c0275788cf97660b52ab23f1f8c7c8d7'] = 'Dades de la filigrana';
$_MODULE['<{watermark}prestashop>watermark_cc99ba657a4a5ecf9d2d7cb974d25596'] = 'Un cop hagueu configurat el mòdul, torneu a generar les imatges amb les \"Imatges\" de l\'eina en les preferències. No obstant això, la marca d\'aigua s\'afegeix automàticament a les noves imatges.';
$_MODULE['<{watermark}prestashop>watermark_c23549e174914e9796db47d27c49eb95'] = 'Sense marca d\'aigua carregat.';
$_MODULE['<{watermark}prestashop>watermark_c9519bff5a6fe31e0f26b1c52dad7ad8'] = 'Arxiu de filigrana';
$_MODULE['<{watermark}prestashop>watermark_ce4ca541df51a63fd8e78e0da29e1d44'] = 'Han d\'estar en format GIF';
$_MODULE['<{watermark}prestashop>watermark_3ccc25c1409aec574beb82bad14b5ebc'] = 'Transparència de la filigrana (0-100)';
$_MODULE['<{watermark}prestashop>watermark_acf0fa79a73731e7d70cb208a62c249a'] = 'Alineació X de la filigrana';
$_MODULE['<{watermark}prestashop>watermark_489f2e730102b59aec48b5c27d2cbe1c'] = 'Alineació Y de la filigrana';
$_MODULE['<{watermark}prestashop>watermark_8d92a725c5abead5353e60e0b2fc7d6d'] = 'Trieu els tipus d\'imatge per a la protecció amb filigrana';
$_MODULE['<{watermark}prestashop>watermark_b17f3f4dcf653a5776792498a9b44d6a'] = 'Modificar configuració';
$_MODULE['<{watermark}prestashop>watermark_220d9102465c9223781b8f99af48c154'] = 'La imatge de marca d\'aigua no és un gif real, si us plau, convertir la imatge.';


$_MODULE['<{watermark}prestashop>watermark_872e6b7b596ba4f395669f1fc7ce9974'] = 'Aquest mòdul de Prestashop ha estat modificat i millorat per';
$_MODULE['<{watermark}prestashop>watermark_25c5b70b569b15316bfcf561f68fbeec'] = '* Si aquest mòdul t ha estat d utilitat i t és possible, t agrairia enormement si fessis una donació, em ajudarà a continuar millorant!';
$_MODULE['<{watermark}prestashop>watermark_caf45c4c99de0621b7f954625234b480'] = '* El convido a descobrir altres mòduls d PrestaShop';
$_MODULE['<{watermark}prestashop>watermark_6181061bda29c9835ee598681f42972d'] = 'visitant aquesta pàgina.';
$_MODULE['<{watermark}prestashop>watermark_cbb4d3dccd7508314fc733d97faee7f5'] = 'Valor actual:';
$_MODULE['<{watermark}prestashop>watermark_bc593fec128401a0317fcc850a67a115'] ='Ha de tenir format PNG';
$_MODULE['<{watermark}prestashop>watermark_34fc7767a43be8e05ecf735ba89b93f3'] ='Proporció de marca daigua davant imatge original';

