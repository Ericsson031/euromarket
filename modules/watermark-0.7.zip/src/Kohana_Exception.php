<?php

class Kohana_Exception extends ErrorException {}