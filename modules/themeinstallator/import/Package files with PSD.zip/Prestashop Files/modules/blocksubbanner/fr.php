<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f45e5fd3724e58507445d945a7adaa96'] = 'Ajoute un bloc pour afficher une bannière sur la page d\'accueil sous.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Une erreur s\'est produite lors de l\'image upload.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Impossible d\'écrire dans le fichier de l\'éditeur.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_8072bc856691062b88d30354ab28a27a'] = 'Impossible de fermer le fichier de l\'éditeur.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_93314199c1f5be182040fd88370f44f4'] = 'Impossible de mettre à jour le fichier de l\'éditeur.  S\'il vous plaît vérifier les autorisations d\'écriture du fichier de l\'éditeur.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmation';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_e064d7b8b138ede498cb8face441d5ea'] = 'Bannière Sous #';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_a471bad91e50f02a72e70e54835c6614'] = 'Bannière Sous';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_85b25d9ad3b6ef89b680f004dbfb1da2'] = 'URL bannière sous';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_185ea8c5e7ee3e7ba92714979b033ea3'] = 'Ouvrir le lien dans un nouvel onglet';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_099af53f601532dbd31e0ea99ffdeb64'] = 'supprimer';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_61d67e3175291a85a19866f18ab8df49'] = 'Supprimer cette bannière sous';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_9b838ba01e3eddffba8bb08a0c60513b'] = 'Votre dossier Liens est vide.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_34ec78fcc91ffb1e54cd85e4a0924332'] = 'Ajouter';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_b6b716d7c0a89d5703dceefcd3466ecd'] = 'Ajouter une nouvelle bannière sous';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
