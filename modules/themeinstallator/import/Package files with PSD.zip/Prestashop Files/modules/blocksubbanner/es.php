<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f45e5fd3724e58507445d945a7adaa96'] = 'Agrega un bloque para mostrar un aviso secundario en la página principal.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Se produjo un error durante la carga de imágenes.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_ea83e4005a3edd639f663dc2d1bff0a3'] = 'No se puede escribir en el fichero de editor.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_8072bc856691062b88d30354ab28a27a'] = 'No se puede cerrar el editor de archivos.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_93314199c1f5be182040fd88370f44f4'] = 'No se puede actualizar el archivo del editor.  Por favor, compruebe los permisos de escritura en el archivo del editor.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmación';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_e064d7b8b138ede498cb8face441d5ea'] = 'Banner Sub #';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_a471bad91e50f02a72e70e54835c6614'] = 'Banner Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_85b25d9ad3b6ef89b680f004dbfb1da2'] = 'URL Banner Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_185ea8c5e7ee3e7ba92714979b033ea3'] = 'Abrir vínculo en una pestaña nueva';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_099af53f601532dbd31e0ea99ffdeb64'] = 'borrar';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_61d67e3175291a85a19866f18ab8df49'] = 'Eliminar este Banner Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_9b838ba01e3eddffba8bb08a0c60513b'] = 'El archivo de enlaces está vacía.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_34ec78fcc91ffb1e54cd85e4a0924332'] = 'añadir';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_b6b716d7c0a89d5703dceefcd3466ecd'] = 'Añadir un nuevo Banner Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Ahorrar';
