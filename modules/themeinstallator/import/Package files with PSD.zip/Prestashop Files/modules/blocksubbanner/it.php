<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f45e5fd3724e58507445d945a7adaa96'] = 'Aggiunge un blocco per visualizzare un banner sulla home page sotto.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'È verificato un errore durante il caricamento delle immagini.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Impossibile scrivere sul file di editor.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_8072bc856691062b88d30354ab28a27a'] = 'Non è possibile chiudere il file editor.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_93314199c1f5be182040fd88370f44f4'] = 'Impossibile aggiornare il file editor.  Si prega di controllare i permessi di scrittura del file dell\'editore.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Conferma';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_e064d7b8b138ede498cb8face441d5ea'] = 'Banner Sub #';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_a471bad91e50f02a72e70e54835c6614'] = 'Banner Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_85b25d9ad3b6ef89b680f004dbfb1da2'] = 'Banner URL Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_185ea8c5e7ee3e7ba92714979b033ea3'] = 'Link aperto in una nuova scheda';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_099af53f601532dbd31e0ea99ffdeb64'] = 'cancellare';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_61d67e3175291a85a19866f18ab8df49'] = 'Elimina questo Banner Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_9b838ba01e3eddffba8bb08a0c60513b'] = 'Il file link è vuoto.';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_34ec78fcc91ffb1e54cd85e4a0924332'] = 'aggiungere';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_b6b716d7c0a89d5703dceefcd3466ecd'] = 'Aggiungere un nuovo banner Sub';
$_MODULE['<{blocksubbanner}prestashop>blocksubbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
